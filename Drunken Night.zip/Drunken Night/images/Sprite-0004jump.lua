return {
    frames = {
        {
            x = 0,
            y = 0,
            width = 544,
            height = 512
        }
    }
}