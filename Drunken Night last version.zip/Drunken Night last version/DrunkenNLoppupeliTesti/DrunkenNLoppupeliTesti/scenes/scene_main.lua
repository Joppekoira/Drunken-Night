-- scene_main.lua
-- Pääpelikenttä - kolikkot ja platformit

local composer = require("composer")
local scene = composer.newScene()

-- Fysiikkamoottori
local physics = require("physics")
physics.start()
physics.setDrawMode( "hybrid" )
physics.setGravity(0, 0)

-- Pelaajan liikuttaminen moduuli
local playerMovement = require("scripts.data")
local drunkenguy
local currentFrequence = "walkRight"
local speed = 2

-- Kolikkojärjestelmä
local coinsCollected = 0     -- Kerättyjen kolikkkojen määrä
local COINS_NEEDED = 5         -- Tarvittavien kolikkkojen määrä
local coins = {}
local tiles = {}
local infoBox
local infoBoxBg
local closeButton
local hearts = {}

-- Globaali näppäimistön tila
if not _G.keysPressed then
    _G.keysPressed = {}
end
local keysPressed = _G.keysPressed

-- Globaali terveysympäristö
if not _G.playerHealth then
    _G.playerHealth = 1
end

-- Päivittää sydänten näyttämisen
local function updateHearts()
    for i = 1, 3 do
        if hearts[i] then
            if i <= _G.playerHealth then
                hearts[i].fill = {type="image", filename="images/muutkuvat/rakennukset/heart_full.png"}
            else
                hearts[i].fill = {type="image", filename="images/muutkuvat/rakennukset/heart_empty.png"}
            end
        end
    end
end

-- Näyttää info-ikkunan missä kerrotaan tehtävä
local function showInfoBox(sceneGroup)
    infoBoxBg = display.newRect(display.contentCenterX, display.contentCenterY,
                                 display.contentWidth, display.contentHeight)
    infoBoxBg:setFillColor(0, 0, 0, 0.7)
    sceneGroup:insert(infoBoxBg)

    infoBox = display.newRoundedRect(display.contentCenterX, display.contentCenterY, 400, 350, 12)
    infoBox:setFillColor(0.2, 0.2, 0.3)
    infoBox.strokeWidth = 3
    infoBox:setStrokeColor(1, 0.8, 0)
    sceneGroup:insert(infoBox)

    local title = display.newText("TEHTÄVÄ", display.contentCenterX,
                                  display.contentCenterY - 130, native.systemFontBold, 24)
    title:setFillColor(1, 0.8, 0)
    sceneGroup:insert(title)

    local infoText = display.newText({
    text = "I feel hungry I need to collect " .. COINS_NEEDED .. " Coins to be able to eat some food\n" ..
           "Movement Keys W-A-S-D, arrow keys and Space\n\n" ..
           "Collected Coins:" .. coinsCollected .. "/" .. COINS_NEEDED,
    x = display.contentCenterX,
    y = display.contentCenterY,
    width = 350,
    font = native.systemFont,
    fontSize = 20,
    align = "center"
})
    infoText:setFillColor(1, 1, 1)
    sceneGroup:insert(infoText)

    closeButton = display.newRoundedRect(display.contentCenterX,
                                         display.contentCenterY + 130, 100, 40, 8)
    closeButton:setFillColor(0.8, 0.2, 0.2)
    sceneGroup:insert(closeButton)

    local closeText = display.newText("SULJE", display.contentCenterX,
                                      display.contentCenterY + 130, native.systemFontBold, 22)
    closeText:setFillColor(1, 1, 1)
    sceneGroup:insert(closeText)

    local function closeInfoBox(event)
        if event.phase == "ended" then
            display.remove(infoBoxBg)
            display.remove(infoBox)
            display.remove(title)
            display.remove(infoText)
            display.remove(closeButton)
            display.remove(closeText)
        end
        return true
    end

    closeButton:addEventListener("touch", closeInfoBox)
end

-- Tarkistaa osuuko pelaaja kolikkoon
local function checkCoinCollision(player, coin)
    local dx = player.x - coin.x
    local dy = player.y - coin.y
    local distance = math.sqrt(dx*dx + dy*dy)
    return distance < 50
end

function scene:create(event)
    local sceneGroup = self.view

    -- Näytön dimensiot
    local screenW = 960
    local screenH = 640

    -- Lataa taustakuva
    local backGround = display.newImageRect("images/tile_taivas.png", screenW, screenH)
    backGround.x = display.contentCenterX
    backGround.y = display.contentCenterY
    sceneGroup:insert(backGround)

    -- Lisää lamppuja (koristelu)
    local lampPositions = {
        {x = 50, y = 460}
    }

    for i = 1, #lampPositions do
        local lamp = display.newImageRect("images/muutkuvat/objects/lamppu.png", 80, 180)
        lamp.x = lampPositions[i].x
        lamp.y = lampPositions[i].y
        sceneGroup:insert(lamp)
    end

    -- Baari oikealla puolella (missä pelaaja alkaa)
    local baari = display.newImageRect("images/muutkuvat/rakennukset/baari.png", 360, 400)
    baari.x = screenW - 175
    baari.y = screenH - 220
    sceneGroup:insert(baari)

    -- Info-lamppu ikoni (vasemmassa yläkulmassa)
    local infoLamp = display.newCircle(60, 60, 30)
    infoLamp:setFillColor(1, 0.8, 0)
    sceneGroup:insert(infoLamp)

    local lampText = display.newText("💡", 60, 60, native.systemFont, 40)
    sceneGroup:insert(lampText)

    local function onInfoLampTouch(event)
        if event.phase == "ended" then
            showInfoBox(sceneGroup)
        end
        return true
    end
    infoLamp:addEventListener("touch", onInfoLampTouch)

    -- Kolikkokounter näyttö (oikeassa yläkulmassa)
    local coinCounterBg = display.newRoundedRect(screenW - 100, 60, 150, 50, 8)
    coinCounterBg:setFillColor(0.2, 0.2, 0.3)
    sceneGroup:insert(coinCounterBg)

    local coinCounterText = display.newText("Kolikot: 0/" .. COINS_NEEDED,
                                            screenW - 100, 60, native.systemFontBold, 24)
    coinCounterText:setFillColor(1, 0.8, 0)
    sceneGroup:insert(coinCounterText)

    self.coinCounterText = coinCounterText

    -- Terveyssydämet (yläkeskellä)
    for i = 1, 3 do
        local heart = display.newImageRect("images/muutkuvat/rakennukset/heart_full.png", 32, 32)
        heart.x = screenW/2 - 50 + (i-1)*40
        heart.y = 40
        sceneGroup:insert(heart)
        hearts[i] = heart
    end

    -- Luo laatta-platformit
    local tilePositions = {
        {x = 150, y = 470}, --vasen alhaalla
        {x = 300, y = 430}, --keski-vasen alhaalla
        {x = 450, y = 340}, --keskimmäinen
        {x = 600, y = 450},
        {x = 720, y = 300} --oikea
    }

    for i = 1, 5 do
        local tile = display.newImageRect("images/muutkuvat/tiles/ML.png", 80, 20)
        tile.x = tilePositions[i].x
        tile.y = tilePositions[i].y
        sceneGroup:insert(tile)
        tiles[i] = tile
    end

    self.tiles = tiles

    -- Luo kolikot laattojen päälle
    for i = 1, COINS_NEEDED do
        local coin = display.newImageRect("images/muutkuvat/objects/coin.png", 40, 40)
        coin.x = tilePositions[i].x
        coin.y = tilePositions[i].y - 40
        sceneGroup:insert(coin)

        coins[i] = {image = coin, collected = false}
    end

    self.coins = coins
    self.hearts = hearts

    -- Lataa sprite-kuvasheet
    local walkOptions = require("images.123newch")
    local walkSheet = graphics.newImageSheet("images/123newch.png", walkOptions)

    -- Luo sprite 5-framen animaatioilla
    drunkenguy = display.newSprite(walkSheet, {
        { name="walkRight", frames={1,2,3,4,5}, time=800, loopCount=0 },
        { name="walkLeft", frames={1,2,3,4,5}, time=800, loopCount=0 },
        { name="walkUp", frames={1,2,3,4,5}, time=800, loopCount=0 },
        { name="walkDown", frames={1,2,3,4,5}, time=800, loopCount=0 },
        { name="walkUpRight", frames={1,2,3,4,5}, time=800, loopCount=0 },
        { name="walkUpLeft", frames={1,2,3,4,5}, time=800, loopCount=0 },
        { name="walkDownRight", frames={1,2,3,4,5}, time=800, loopCount=0 },
        { name="walkDownLeft", frames={1,2,3,4,5}, time=800, loopCount=0 }
    })

    drunkenguy.x = 820
    drunkenguy.y = 550
    drunkenguy:setSequence("walkRight")
    drunkenguy.xScale = 0.5
    drunkenguy.yScale = 0.5
    sceneGroup:insert(drunkenguy)

    self.drunkenguy = drunkenguy
    self.sceneGroup = sceneGroup
end

function scene:show(event)
    local phase = event.phase

    if phase == "will" then
        -- Päivitä sydänten näyttö
        updateHearts()

        if event.params and event.params.fromKiosk then
            drunkenguy.x = 50
        end
    end

    if phase == "did" then
        for k in pairs(_G.keysPressed) do
            _G.keysPressed[k] = nil
        end

        -- Näppäimen painamisen kuuntelija
        local function onKey(event)
            if event.phase == "down" then
                keysPressed[event.keyName] = true
            elseif event.phase == "up" then
                keysPressed[event.keyName] = false
            end
            return false
        end

        local sceneActive = true
        -- Pääpelisilmukka
        local function gameLoop()
            if not sceneActive then return end

            -- Päivitä pelaajan liike
            currentFrequence = playerMovement.update(drunkenguy, keysPressed, currentFrequence, speed, self.tiles)

            -- Tarkista kolikkoen kerääminen
            for i = 1, #coins do
                if not coins[i].collected and checkCoinCollision(drunkenguy, coins[i].image) then
                    coins[i].collected = true
                    coins[i].image.isVisible = false
                    coinsCollected = coinsCollected + 1

                    self.coinCounterText.text = "Kolikot: " .. coinsCollected .. "/" .. COINS_NEEDED

                    print("Kolikko kerätty! Yhteensä: " .. coinsCollected .. "/" .. COINS_NEEDED)
                end
            end

            -- Tarkista sceneen siirtyminen - vasemmalle (kauppaan)
            if drunkenguy.x < 0 then
                if coinsCollected >= COINS_NEEDED then
                    sceneActive = false
                    Runtime:removeEventListener("key", self.onKey)
                    Runtime:removeEventListener("enterFrame", self.gameLoop)
                    composer.gotoScene("scenes.scene_kiosk", {
                        effect = "slideLeft",
                        time = 300,
                        params = { fromMain = true }
                    })
                else
                    drunkenguy.x = 50
                    print("Tarvitset vielä " .. (COINS_NEEDED - coinsCollected) .. " kolikkoa!")
                end
            end

            -- Tarkista sceneen siirtyminen - oikealle (baari - ei pääse)
            if drunkenguy.x > 960 then
                drunkenguy.x = 910
                -- Näytä teksti
                local warningText = display.newText({
                    text = "I feel It's a blocked path!",
                    x = drunkenguy.x,
                    y = drunkenguy.y - 100,
                    width = 250,
                    font = native.systemFont,
                    fontSize = 18,
                    align = "center"
                })
                warningText:setFillColor(1, 1, 0)
                self.sceneGroup:insert(warningText)

                -- Poista teksti 2 sekunnin jälkeen
                timer.performWithDelay(2000, function()
                    display.remove(warningText)
                end)
            end
        end

        Runtime:addEventListener("key", onKey)
        Runtime:addEventListener("enterFrame", gameLoop)

        self.onKey = onKey
        self.gameLoop = gameLoop
    end
end

function scene:hide(event)
    local phase = event.phase

    if phase == "will" then
        if self.onKey then
            Runtime:removeEventListener("key", self.onKey)
        end
        if self.gameLoop then
            Runtime:removeEventListener("enterFrame", self.gameLoop)
        end

        for k in pairs(_G.keysPressed) do
            _G.keysPressed[k] = nil
        end
    end
end

function scene:destroy(event)
    -- Siivous jos tarpeen
end

scene:addEventListener("create", scene)
scene:addEventListener("show", scene)
scene:addEventListener("hide", scene)
scene:addEventListener("destroy", scene)

return scene