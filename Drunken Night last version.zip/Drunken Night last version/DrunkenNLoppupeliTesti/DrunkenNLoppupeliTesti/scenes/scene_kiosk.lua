-- scene_kiosk.lua
-- Kioski scene - Hot-dog kauppa

local composer = require("composer")
local scene = composer.newScene()
local physics = require("physics")

-- Pelaajan liikuttaminen moduuli
local playerMovement = require("scripts.data")
local drunkenguy
local currentFrequence = "walkRight"
local speed = 2
local hearts = {}
local vomitObjects = {}

-- Globaali näppäimistön tila
if not _G.keysPressed then
    _G.keysPressed = {}
end
local keysPressed = _G.keysPressed

-- Globaali terveysympäristö
if not _G.playerHealth then
    _G.playerHealth = 3
end

-- Globaali kolikkojärjestelmä
if not _G.playerCoins then
    _G.playerCoins = 10  -- Aloita 10 kolikolla
end

-- Tarkistaa oksentamisen törmäyksen
local function checkVomitCollision(player, vomit)
    local dx = player.x - vomit.x
    local dy = player.y - vomit.y
    local distance = math.sqrt(dx*dx + dy*dy)
    return distance < 60
end

-- Päivittää sydänten näyttämisen
local function updateHearts()
    for i = 1, 3 do
        if hearts[i] then
            if i <= _G.playerHealth then
                hearts[i].fill = {type="image", filename="images/muutkuvat/rakennukset/heart_full.png"}
            else
                hearts[i].fill = {type="image", filename="images/muutkuvat/rakennukset/heart_empty.png"}
            end
        end
    end
end

-- Vahingon käsittelijä - vähentää pelaajan terveyttä
local function damagePlayer()
    if _G.playerHealth > 0 then
        _G.playerHealth = _G.playerHealth - 0.5
        updateHearts()
        print("Terveys: " .. _G.playerHealth)

        if _G.playerHealth <= 0 then
            print("Peli loppu!")
            -- Nollaa terveys ja mene menu-näyttöön
            _G.playerHealth = 1
            composer.gotoScene("scenes.scene_menu", {effect = "fade", time = 500})
        end
    end
end

function scene:create(event)
    local sceneGroup = self.view

    -- Käynnistä fysiikkamoottori
    physics.start()
    physics.setGravity(0, 0)  -- Ei painovoimaa top-down näkymälle
    physics.setDrawMode("normal")  -- Näytä fysiikan runko-osat

    -- Hae näytön dimensiot
    local screenW = display.contentWidth
    local screenH = display.contentHeight

    -- Lataa taustakuva
    local backGround = display.newImageRect("images/tile_taivas.png", screenW, screenH)
    backGround.x = display.contentCenterX
    backGround.y = display.contentCenterY
    sceneGroup:insert(backGround)

    -- Lataa kioski (vasemmalla puolella, alempi)
    local kiosk = display.newImageRect("images/rakennus_nakkikiska.png", 300, 300)
    kiosk.x = 100
    kiosk.y = display.contentCenterY + 115
    sceneGroup:insert(kiosk)

    -- Asiakas (NPC - käyttää samaa kuvaa kuin pelaaja)
    local npcSheet = graphics.newImageSheet("images/123newch.png", require("images.123newch"))
    local customer = display.newSprite(npcSheet, {
        { name="walkRight", frames={1,2,3,4,5}, time=600, loopCount=0 },
        { name="walkLeft", frames={1,2,3,4,5}, time=600, loopCount=0 },
    })
    customer.x = display.contentCenterX  -- Aloita keskeltä
    customer.y = kiosk.y + 90
    customer:setSequence("walkRight")
    customer.xScale = 0.5
    customer.yScale = 0.5
    customer:setFillColor(0, 1, 0)  -- Vihreä väri
    customer.alpha = 0.5  -- Puoli-läpinäkyvä
    customer.hasPlayedAnimation = false
    sceneGroup:insert(customer)

    -- Lisää fysiikka-runko asiakkaalle
    physics.addBody(customer, "static", { bounce=0, radius=8 })
    customer.name = "npc"
    self.customer = customer  -- Tallenna viite scene-oliolle

    -- Kauppiaan keskustelun tekstikupla (alkaa kioski-sijainnista)
    local speechBubble = display.newRoundedRect(kiosk.x - 50, kiosk.y - 80, 190, 70, 8)
    speechBubble:setFillColor(0.7, 0.7, 0.7)  -- Harmaa
    speechBubble.alpha = 0.7
    speechBubble.strokeWidth = 2
    speechBubble:setStrokeColor(0, 0, 0)
    speechBubble.isVisible = false  -- Piilotettu alussa
    sceneGroup:insert(speechBubble)

    local speechText = display.newText({
        text = "",  -- Alkaa tyhjänä, täyttyy kirjain kerrallaan
        x = kiosk.x - 50,
        y = kiosk.y - 80,
        width = 170,
        font = native.systemFont,
        fontSize = 14,
        align = "center"
    })
    speechText:setFillColor(0, 0, 0)
    sceneGroup:insert(speechText)

    -- Asiakkaan keskustelun tekstikupla (alkaa ruudun ulkopuolelta)
    local npcSpeechBubble = display.newRoundedRect(-200, kiosk.y - 100, 190, 70, 8)
    npcSpeechBubble:setFillColor(0.7, 0.7, 0.7)  -- Harmaa
    npcSpeechBubble.alpha = 0.7
    npcSpeechBubble.strokeWidth = 2
    npcSpeechBubble:setStrokeColor(0, 0, 0)
    npcSpeechBubble.isVisible = false  -- Piilotettu alussa
    sceneGroup:insert(npcSpeechBubble)

    local npcSpeechText = display.newText({
        text = "",  -- Alkaa tyhjänä, täyttyy kirjain kerrallaan
        x = -200,
        y = kiosk.y - 100,
        width = 170,
        font = native.systemFont,
        fontSize = 14,
        align = "center"
    })
    npcSpeechText:setFillColor(0, 0, 0)
    sceneGroup:insert(npcSpeechText)

    -- Store for animation
    self.speechBubble = speechBubble
    self.speechText = speechText
    self.npcSpeechBubble = npcSpeechBubble
    self.npcSpeechText = npcSpeechText

    -- Add lamps (decorative)
    local lampPositions = {
        {x = 500, y = 460},
    }

    for i = 1, #lampPositions do
        local lamp = display.newImageRect("images/muutkuvat/objects/lamppu.png", 80, 180)
        lamp.x = lampPositions[i].x
        lamp.y = lampPositions[i].y
        sceneGroup:insert(lamp)
    end


    -- Add vomit objects (hazards)
    local vomitPositions = {
        {x = 650, y = 570},
        {x = 850, y = 550},
    }

    for i = 1, #vomitPositions do
        local vomit = display.newImageRect("images/muutkuvat/objects/oksennus_obj.png", 70, 30)
        vomit.x = vomitPositions[i].x
        vomit.y = vomitPositions[i].y
        sceneGroup:insert(vomit)
        vomit.hasHit = false

        -- Add physics body for vomit
        physics.addBody(vomit, "static", { bounce=0 })
        vomit.collision = function(self, event)
            if event.phase == "began" then
                print("Hit vomit at: " .. self.x .. ", " .. self.y)
            end
        end
        vomit:addEventListener("collision", vomit)

        table.insert(vomitObjects, vomit)
    end

    -- Health hearts
    for i = 1, 3 do
        local heart = display.newImageRect("images/muutkuvat/rakennukset/heart_full.png", 32, 32)
        heart.x = screenW - 40 - (i-1)*40
        heart.y = 40
        sceneGroup:insert(heart)
        hearts[i] = heart
    end

    -- Coins display
    local coinsText = display.newText({
        text = "Coins: " .. _G.playerCoins,
        x = screenW - 100,
        y = 80,
        width = 150,
        font = native.systemFont,
        fontSize = 16,
        align = "right"
    })
    coinsText:setFillColor(1, 1, 0)  -- Keltainen
    sceneGroup:insert(coinsText)
    self.coinsText = coinsText

    -- Load sprite sheet
    local walkOptions = require("images.123newch")
    local walkSheet = graphics.newImageSheet("images/123newch.png", walkOptions)

    -- Create sprite
    drunkenguy = display.newSprite(walkSheet, {
        { name="walkRight", frames={1,2,3,4,5}, time=1000, loopCount=0 },
        { name="walkLeft", frames={1,2,3,4,5}, time=1000, loopCount=0 },
        { name="walkUp", frames={1,2,3,4,5}, time=1000, loopCount=0 },
        { name="walkDown", frames={1,2,3,4,5}, time=1000, loopCount=0 },
        { name="walkUpRight", frames={1,2,3,4,5}, time=1000, loopCount=0 },
        { name="walkUpLeft", frames={1,2,3,4,5}, time=1000, loopCount=0 },
        { name="walkDownRight", frames={1,2,3,4,5}, time=1000, loopCount=0 },
        { name="walkDownLeft", frames={1,2,3,4,5}, time=1000, loopCount=0 }
    })

    drunkenguy.x = display.contentCenterX
    drunkenguy.y = 490
    drunkenguy:setSequence("walkRight")
    drunkenguy.xScale = 0.5
    drunkenguy.yScale = 0.5
    sceneGroup:insert(drunkenguy)

    -- Add physics body to player (scaled to match sprite size)
    physics.addBody(drunkenguy, "dynamic", { bounce=0, radius=8 })
    drunkenguy.collision = function(self, event)
        if event.phase == "began" then
            print("Player collided with: " .. tostring(event.other.name or "unknown"))
        end
    end
    drunkenguy:addEventListener("collision", drunkenguy)

    -- Save to scene data
    self.kiosk = kiosk
    self.vomitObjects = vomitObjects
    self.hearts = hearts
    self.customer = customer
    self.sceneGroup = sceneGroup
    self.drunkenguy = drunkenguy
end

function scene:show(event)
    local phase = event.phase

    if phase == "will" then
        -- Update health display
        updateHearts()

        -- When coming from main scene (left), place character on right side
        if event.params and event.params.fromMain then
            self.drunkenguy.x = display.contentWidth - 50
            self.hasStartedDialog = false  -- Track if dialog sequence has started

            -- Set up a timer to check if player is close to NPC
            local function startDialogWhenPlayerNear()
                self.dialogCheckInterval = timer.performWithDelay(100, function()
                    -- Check if player is close to NPC (within 150 pixels)
                    local dx = self.drunkenguy.x - self.customer.x
                    local dy = self.drunkenguy.y - self.customer.y
                    local distance = math.sqrt(dx*dx + dy*dy)

                    if distance < 150 and not self.hasStartedDialog then
                        self.hasStartedDialog = true

                        -- Cancel the interval timer
                        if self.dialogCheckInterval then
                            timer.cancel(self.dialogCheckInterval)
                            self.dialogCheckInterval = nil
                        end

                        -- FIRST: NPC alkaa kävellä keskeltä kohti kioskia JA PELAA ANIMAATIOTA (vasemmalle)
                        self.customer.xScale = -0.5  -- Käännä vasemmalle
                        self.customer:play()  -- Aloita animaatio
                        transition.to(self.customer, {
                            time = 4000,
                            x = self.kiosk.x + 30,  -- Liikkuu kohti kioskia
                            onComplete = function()
                                -- Pysäytä animaatio kun saapuu kioskille
                                self.customer:pause()

                                -- TARKISTA: Onko pelaaja lähellä kioskia? Jos ei, älä aloita dialogia
                                local dxPlayer = self.drunkenguy.x - self.kiosk.x
                                local dyPlayer = self.drunkenguy.y - self.kiosk.y
                                local playerDistance = math.sqrt(dxPlayer*dxPlayer + dyPlayer*dyPlayer)

                                -- Dialogi käynnistyy vain jos pelaaja on lähellä kioskia (alle 200 pixelia)
                                if playerDistance < 200 then
                                    -- Kauppias alkaa puhua kun asiakas saapuu kioskille
                                    local fullShopkeeperText =
                                        "Vendor: There is only one hot‑dog left, and " ..
                                        "there are two of you. Well simply whoever " ..
                                        "offers the most gets it."
                                    local shopkeeperCharIndex = 1
                                    local function addShopkeeperChar()
                                        if shopkeeperCharIndex <= #fullShopkeeperText then
                                            self.npcSpeechText.text = string.sub(fullShopkeeperText, 1, shopkeeperCharIndex)
                                            shopkeeperCharIndex = shopkeeperCharIndex + 1
                                            timer.performWithDelay(80, addShopkeeperChar)
                                        end
                                    end

                                    self.npcSpeechBubble.isVisible = true  -- Näytä bubble
                                    self.npcSpeechBubble.x = self.kiosk.x + 100
                                    self.npcSpeechText.x = self.kiosk.x + 100
                                    addShopkeeperChar()

                                    -- Laske kauppiaan puheen kesto ja lisää 2 sekuntia
                                    local shopkeeperDuration = #fullShopkeeperText * 80 + 2000

                                    -- NPC alkaa puhua kauppiaan jälkeen + 2 sekuntia
                                    timer.performWithDelay(shopkeeperDuration, function()
                                        self.npcSpeechText.text = ""
                                        self.npcSpeechBubble.x = -200
                                        self.npcSpeechText.x = -200

                                        local fullNpcText = "Random Guy: I'll pay two coins"
                                        local npcCharIndex = 1
                                        local function addNpcChar()
                                            if npcCharIndex <= #fullNpcText then
                                                self.npcSpeechText.text = string.sub(fullNpcText, 1, npcCharIndex)
                                                npcCharIndex = npcCharIndex + 1
                                                timer.performWithDelay(80, addNpcChar)
                                            end
                                        end

                                        self.npcSpeechBubble.x = self.customer.x
                                        self.npcSpeechText.x = self.customer.x
                                        addNpcChar()

                                        -- Laske NPC:n puheen kesto ja lisää 2 sekuntia
                                        local npcDuration = #fullNpcText * 80 + 2000

                                        -- Pelaaja puhuu NPC:n jälkeen + 2 sekuntia
                                        timer.performWithDelay(npcDuration, function()
                                            self.npcSpeechText.text = ""
                                            self.npcSpeechBubble.x = -200
                                            self.npcSpeechText.x = -200

                                            -- Pelaaja puhuu - TARKISTA ONKO TARPEEKSI KOLIKOITA (2 kolikkoa)
                                            if _G.playerCoins >= 2 then
                                                -- Pelaaja puhuu oman puhelimen kautta
                                                local fullPlayerText = "Player: Give it to me right now, I'll double his offer. Four coins."
                                                local playerCharIndex = 1
                                                local function addPlayerChar()
                                                    if playerCharIndex <= #fullPlayerText then
                                                        self.npcSpeechText.text = string.sub(fullPlayerText, 1, playerCharIndex)
                                                        playerCharIndex = playerCharIndex + 1
                                                        timer.performWithDelay(80, addPlayerChar)
                                                    end
                                                end

                                                self.npcSpeechBubble.x = self.drunkenguy.x
                                                self.npcSpeechText.x = self.drunkenguy.x
                                                addPlayerChar()

                                                -- Laske pelaajan puheen kesto ja lisää 2 sekuntia
                                                local playerDuration = #fullPlayerText * 80 + 2000

                                                -- Kauppias vastaa pelaajan jälkeen + 2 sekuntia
                                                timer.performWithDelay(playerDuration, function()
                                                    self.npcSpeechText.text = ""
                                                    self.npcSpeechBubble.x = -200
                                                    self.npcSpeechText.x = -200

                                                    local fullShopkeeperResponse = "Vendor: Oh, that's an amazing offer. Alright, here you go."
                                                    local shopkeeperResponseCharIndex = 1
                                                    local function addShopkeeperResponseChar()
                                                        if shopkeeperResponseCharIndex <= #fullShopkeeperResponse then
                                                            self.npcSpeechText.text = string.sub(fullShopkeeperResponse, 1, shopkeeperResponseCharIndex)
                                                            shopkeeperResponseCharIndex = shopkeeperResponseCharIndex + 1
                                                            timer.performWithDelay(80, addShopkeeperResponseChar)
                                                        end
                                                    end

                                                    self.npcSpeechBubble.x = self.kiosk.x + 100
                                                    self.npcSpeechText.x = self.kiosk.x + 100
                                                    addShopkeeperResponseChar()

                                                    -- Laske kauppiaan vastauksen kesto ja lisää 2 sekuntia
                                                    local shopkeeperResponseDuration = #fullShopkeeperResponse * 80 + 2000

                                                    -- NPC muttelee kauppiaan jälkeen + 2 sekuntia
                                                    timer.performWithDelay(shopkeeperResponseDuration, function()
                                                        -- NPC muttelee: "I'll show him… He'll taste my wrath..."
                                                        local fullNpcMuttering =
                                                            "Random Guy: I'll show him… He'll taste my wrath. " ..
                                                            "It's over for him. I'll prove who's " ..
                                                            "the boss here."
                                                        local npcMutteringCharIndex = 1
                                                        local function addNpcMutteringChar()
                                                            if npcMutteringCharIndex <= #fullNpcMuttering then
                                                                self.npcSpeechText.text = string.sub(fullNpcMuttering, 1, npcMutteringCharIndex)
                                                                npcMutteringCharIndex = npcMutteringCharIndex + 1
                                                                timer.performWithDelay(80, addNpcMutteringChar)
                                                            end
                                                        end

                                                        self.npcSpeechBubble.x = self.customer.x
                                                        self.npcSpeechText.x = self.customer.x
                                                        addNpcMutteringChar()

                                                        -- Laske mutteringin kesto ja lisää 2 sekuntia
                                                        local npcMutteringDuration = #fullNpcMuttering * 80 + 2000

                                                        -- Pelaaja puhuu mutteringin jälkeen + 2 sekuntia
                                                        timer.performWithDelay(npcMutteringDuration, function()
                                                            self.npcSpeechText.text = ""
                                                            self.npcSpeechBubble.x = -200
                                                            self.npcSpeechText.x = -200

                                                            local fullPlayerWarning =
                                                                "Player: You see the random guy taking some kind of " ..
                                                                "red pill, I think it's a bad sign"
                                                            local playerWarningCharIndex = 1
                                                            local function addPlayerWarningChar()
                                                                if playerWarningCharIndex <= #fullPlayerWarning then
                                                                    self.npcSpeechText.text = string.sub(fullPlayerWarning, 1, playerWarningCharIndex)
                                                                    playerWarningCharIndex = playerWarningCharIndex + 1
                                                                    timer.performWithDelay(80, addPlayerWarningChar)
                                                                end
                                                            end

                                                            self.npcSpeechBubble.x = self.drunkenguy.x
                                                            self.npcSpeechText.x = self.drunkenguy.x
                                                            addPlayerWarningChar()

                                                            -- Laske pelaajan varoituksen kesto ja lisää 2 sekuntia
                                                            local playerWarningDuration = #fullPlayerWarning * 80 + 2000

                                                            -- Näytä hotdogi pelaajan varoituksen jälkeen + 2 sekuntia
                                                            timer.performWithDelay(playerWarningDuration, function()
                                                                self.npcSpeechText.text = ""
                                                                self.npcSpeechBubble.x = -200
                                                                self.npcSpeechText.x = -200

                                                                -- Näytä hotdogi pelaajan vieressä
                                                                local hotdog = display.newImageRect("images/muutkuvat/objects/hodari_obj.png", 80, 50)
                                                                hotdog.x = self.drunkenguy.x
                                                                hotdog.y = self.drunkenguy.y - 80
                                                                self.sceneGroup:insert(hotdog)

                                                                -- Näytä "Press SPACE to eat" teksti
                                                                local eatPrompt = display.newText({
                                                                    text = "Press SPACE to eat",
                                                                    x = display.contentCenterX,
                                                                    y = display.contentCenterY + 80,
                                                                    width = 200,
                                                                    font = native.systemFont,
                                                                    fontSize = 16,
                                                                    align = "center"
                                                                })
                                                                eatPrompt:setFillColor(1, 1, 1)  -- Valkoinen
                                                                self.sceneGroup:insert(eatPrompt)
                                                                self.eatPrompt = eatPrompt
                                                                self.hotdog = hotdog
                                                                self.canEatHotdog = true
                                                            end)
                                                        end)
                                                    end)
                                                end)
                                            else
                                                -- Ei tarpeeksi kolikoita!
                                                local noCoinsText = "I don't have enough coins!"
                                                local noCoinsCharIndex = 1
                                                local function addNoCoinsChar()
                                                    if noCoinsCharIndex <= #noCoinsText then
                                                        self.npcSpeechText.text = string.sub(noCoinsText, 1, noCoinsCharIndex)
                                                        noCoinsCharIndex = noCoinsCharIndex + 1
                                                        timer.performWithDelay(80, addNoCoinsChar)
                                                    end
                                                end

                                                self.npcSpeechBubble.x = self.drunkenguy.x
                                                self.npcSpeechText.x = self.drunkenguy.x
                                                addNoCoinsChar()

                                                -- 3 sekuntia myöhemmin, poista teksti
                                                timer.performWithDelay(3000, function()
                                                    self.npcSpeechText.text = ""
                                                    self.npcSpeechBubble.x = -200
                                                    self.npcSpeechText.x = -200
                                                    self.hasStartedDialog = false  -- Salli dialog uudelleen
                                                end)
                                            end
                                        end)
                                    end)
                                else
                                    -- Pelaaja on liian kaukana, älä aloita dialogia
                                    self.hasStartedDialog = false
                                end
                            end
                        })
                    end
                end, 0)
            end

            startDialogWhenPlayerNear()
        end
        -- When coming from street scene (right), place character on left side
        if event.params and event.params.fromStreet then
            self.drunkenguy.x = 50
        end
    end

    if phase == "did" then
        -- Reset keys first
        for k in pairs(_G.keysPressed) do
            _G.keysPressed[k] = nil
        end

        -- Reset vomit hit status
        for i = 1, #self.vomitObjects do
            self.vomitObjects[i].hasHit = false
        end

        -- Keyboard listener
        local function onKey(event)
            if event.phase == "down" then
                keysPressed[event.keyName] = true

                -- EAT HOTDOG when pressing SPACE
                if event.keyName == "space" and self.canEatHotdog then
                    self.canEatHotdog = false

                    -- Poista hotdog ja prompti
                    display.remove(self.hotdog)
                    display.remove(self.eatPrompt)

                    -- Vähennä kolikot
                    _G.playerCoins = _G.playerCoins - 2
                    self.coinsText.text = "Coins: " .. _G.playerCoins

                    -- Näytä "PAYING 4 COINS" teksti
                    local payingText = display.newText({
                        text = "PAYING 4 COINS",
                        x = drunkenguy.x,
                        y = drunkenguy.y - 150,
                        width = 200,
                        font = native.systemFont,
                        fontSize = 20,
                        align = "center"
                    })
                    payingText:setFillColor(1, 0, 0)  -- Punainen
                    self.sceneGroup:insert(payingText)

                    -- 1 sekunti myöhemmin, näytä "EATING.." teksti
                    timer.performWithDelay(1000, function()
                        display.remove(payingText)

                        local eatingText = display.newText({
                            text = "EATING..",
                            x = drunkenguy.x,
                            y = drunkenguy.y - 80,
                            width = 200,
                            font = native.systemFont,
                            fontSize = 20,
                            align = "center"
                        })
                        eatingText:setFillColor(1, 1, 0)  -- Keltainen
                        self.sceneGroup:insert(eatingText)

                        -- 1 sekunti myöhemmin, täytä terveysarvot
                        timer.performWithDelay(1000, function()
                            display.remove(eatingText)

                            -- Täytä terveysarvot
                            _G.playerHealth = 3
                            updateHearts()

                            -- Näytä "+FULL HEALTH" teksti vihreällä
                            local healthText = display.newText({
                                text = "+FULL HEALTH",
                                x = drunkenguy.x,
                                y = drunkenguy.y - 120,
                                width = 200,
                                font = native.systemFont,
                                fontSize = 24,
                                align = "center"
                            })
                            healthText:setFillColor(0, 1, 0)  -- Vihreä
                            self.sceneGroup:insert(healthText)

                            -- 2 sekuntia myöhemmin, poista teksti ja ota syöty-flagi käyttöön
                            timer.performWithDelay(2000, function()
                                display.remove(healthText)
                                self.hasEatenHotdog = true
                            end)
                        end)
                    end)
                    return true
                end
            elseif event.phase == "up" then
                keysPressed[event.keyName] = false
            end
            return false
        end

        -- Continuous update
        local sceneActive = true
        local function gameLoop()
            if not sceneActive then return end

            currentFrequence = playerMovement.update(self.drunkenguy, keysPressed, currentFrequence, speed)

            -- Check vomit collision
            for i = 1, #self.vomitObjects do
                local vomit = self.vomitObjects[i]
                if not vomit.hasHit and checkVomitCollision(self.drunkenguy, vomit) then
                    vomit.hasHit = true
                    damagePlayer()
                end
            end

            -- Check scene transition: right -> main
            if self.drunkenguy.x > display.contentWidth then
                sceneActive = false
                Runtime:removeEventListener("key", self.onKey)
                Runtime:removeEventListener("enterFrame", self.gameLoop)
                composer.gotoScene("scenes.scene_main", {
                    effect = "slideLeft",
                    time = 300,
                    params = { fromKiosk = true }
                })
            end

            -- Check scene transition: left -> street (jos hotdog on syöty)
            if self.hasEatenHotdog and self.drunkenguy.x < 0 then
                sceneActive = false
                Runtime:removeEventListener("key", self.onKey)
                Runtime:removeEventListener("enterFrame", self.gameLoop)
                composer.gotoScene("scenes.scene_street", {
                    effect = "slideLeft",
                    time = 300,
                    params = { fromKiosk = true }
                })
            end
        end

        Runtime:addEventListener("key", onKey)
        Runtime:addEventListener("enterFrame", gameLoop)

        -- Save listeners for cleanup
        self.onKey = onKey
        self.gameLoop = gameLoop
    end
end

function scene:hide(event)
    local phase = event.phase

    if phase == "will" then
        -- Remove listeners
        if self.onKey then
            Runtime:removeEventListener("key", self.onKey)
        end
        if self.gameLoop then
            Runtime:removeEventListener("enterFrame", self.gameLoop)
        end
        if self.dialogCheckInterval then
            timer.cancel(self.dialogCheckInterval)
            self.dialogCheckInterval = nil
        end

        -- Reset all key presses
        for k in pairs(_G.keysPressed) do
            _G.keysPressed[k] = nil
        end

        -- Pause physics
        physics.pause()
    end
end

function scene:destroy(event)
    -- Cleanup if needed
end

scene:addEventListener("create", scene)
scene:addEventListener("show", scene)
scene:addEventListener("hide", scene)
scene:addEventListener("destroy", scene)

return scene