-- main.lua
-- Pelin pääohjelma

-- Piilota tilapalkki näytöltä
display.setStatusBar(display.HiddenStatusBar)

-- Lataa composer-järjestelmä scenejen hallintaa varten
local composer = require("composer")

-- Siirrytään menu sceneen pelin käynnistyessä
composer.gotoScene("scenes.scene_menu")