-- data.lua
-- Pelaajan liikuttamisen ja animaation hallintamoduuli

local playerMovement = {}

-- Pelialueen rajat
local MIN_Y = 490        -- Pienin Y-koordinaatti (maanpinta)
local MAX_Y = display.contentHeight - 50  -- Suurin Y-koordinaatti

-- Hypyn muuttujat
local isJumping = false      -- Onko pelaaja hyppäämässä
local jumpVelocity = 0       -- Hypyn nopeus
local JUMP_POWER = -15       -- Hypyn voima
local GRAVITY = 0.8          -- Painovoima

-- Tarkistaa törmäyksen laattaan/platformiin
local function checkTileCollision(character, tiles)
    if not tiles then return false, nil end

    -- Hahmon rajakoordinaatit (0.5 skaalalle: 50 pikseliä leveys, 40 pikseliä korkeus)
    local charLeft = character.x - 50
    local charRight = character.x + 50
    local charBottom = character.y + 40  -- +40 collision offset

    -- Tarkistaa jokaista laattaa vastaan
    for i = 1, #tiles do
        local tile = tiles[i]
        if tile then
            local tileLeft = tile.x - 50
            local tileRight = tile.x + 50
            local tileTop = tile.y - 20
            local tileBottom = tile.y + 20

            -- Törmäystarkistus
            if charBottom >= tileTop and charBottom <= tileBottom + 10 and
               charRight > tileLeft and charLeft < tileRight then
                return true, tile.y - 40  -- Aseta hahmon y paikka laatan päälle
            end
        end
    end

    return false, nil
end

-- Päivittää pelaajan liiketta ja animaatiota
function playerMovement.update(character, keysPressed, currentSequence, speed, tiles)
    local moveX = 0  -- Vaakasuuntainen liike
    local moveY = 0  -- Pystysuuntainen liike
    local newSequence = nil  -- Uusi animaatiosarja

    -- Vaakasuuntainen liike (oikea/vasen)
    if keysPressed["right"] or keysPressed["d"] then
        moveX = speed
    end
    if keysPressed["left"] or keysPressed["a"] then
        moveX = -speed
    end

    -- Pystysuuntainen liike (ylös/alas) - vain kun ei hypätä
    if not isJumping then
        if keysPressed["up"] or keysPressed["w"] then
            moveY = -speed
        end
        if keysPressed["down"] or keysPressed["s"] then
            moveY = speed
        end
    end

    -- Hyppääminen välilyönnillä
    if (keysPressed["space"]) and not isJumping then
        isJumping = true
        jumpVelocity = JUMP_POWER
    end

    -- Käytä painovoimaa
    if isJumping then
        jumpVelocity = jumpVelocity + GRAVITY
        character.y = character.y + jumpVelocity

        -- Tarkista onko maassa
        if character.y >= MIN_Y then
            character.y = MIN_Y
            isJumping = false
            jumpVelocity = 0
        end

        -- Tarkista laattaan osuminen
        local onTile, tileY = checkTileCollision(character, tiles)
        if onTile and jumpVelocity > 0 then
            character.y = tileY
            isJumping = false
            jumpVelocity = 0
        end

        newSequence = "jump"
    else
        -- Tarkista pitääkö alkaa putoamaan
        local onTile = checkTileCollision(character, tiles)
        if not onTile and character.y < MIN_Y then
            isJumping = true
            jumpVelocity = 0
        end

        -- Animaatiosarjat liikkeelle
        if moveX ~= 0 or moveY ~= 0 then
            if moveX > 0 and moveY == 0 then
                newSequence = "walkRight"
            elseif moveX < 0 and moveY == 0 then
                newSequence = "walkLeft"
            elseif moveX == 0 and moveY < 0 then
                newSequence = "walkUp"
            elseif moveX == 0 and moveY > 0 then
                newSequence = "walkDown"
            elseif moveX > 0 and moveY < 0 then
                newSequence = "walkUpRight"
            elseif moveX < 0 and moveY < 0 then
                newSequence = "walkUpLeft"
            elseif moveX > 0 and moveY > 0 then
                newSequence = "walkDownRight"
            elseif moveX < 0 and moveY > 0 then
                newSequence = "walkDownLeft"
            end
        end
    end

    -- Vaihda animaatiosarja jos tarpeen
    if newSequence and currentSequence ~= newSequence then
        character:setSequence(newSequence)
        currentSequence = newSequence
        character:play()
    end

    -- Aseta hahmon skaalaus (0.5 tarkoittaa puolet normaalisesta koosta)
    if not isJumping then
        if moveX > 0 then
            character.xScale = 0.5      -- Oikea
        elseif moveX < 0 then
            character.xScale = -0.5     -- Vasen (peilattu)
        end
    end

    -- Liikuta hahmoa
    if moveX ~= 0 then
        character.x = character.x + moveX
        if not isJumping then
            character:play()
        end
    elseif moveY ~= 0 and not isJumping then
        local newY = character.y + moveY
        if newY < MIN_Y then newY = MIN_Y end
        if newY > MAX_Y then newY = MAX_Y end
        character.y = newY
        character:play()
    else
        -- Pysähdy jos ei liiku
        if not isJumping then
            character:pause()
        end
    end

    return currentSequence
end

return playerMovement