-- main.lua
display.setStatusBar(display.HiddenStatusBar)
local composer = require("composer")
composer.gotoScene("scenes.scene_menu")