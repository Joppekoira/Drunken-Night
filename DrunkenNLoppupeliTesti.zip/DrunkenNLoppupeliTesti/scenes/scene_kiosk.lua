-- Kiosk Scene (Korjatut sydämet)
local composer = require("composer")
local scene = composer.newScene()
local physics = require("physics")

-- Forward declarations
local playerMovement = require("scripts.data")
local drunkenguy
local kiosk
local kioskCollisionBox
local currentFrequence = "walkRight"
local speed = 2
local hearts = {}
local vomitObjects = {}

-- Global keys table
if not _G.keysPressed then
    _G.keysPressed = {}
end
local keysPressed = _G.keysPressed

-- Global health tracking
if not _G.playerHealth then
    _G.playerHealth = 3
end

-- Global coins tracking
if not _G.playerCoins then
    _G.playerCoins = 10  -- Aloita 10 kolikolla
end

-- Collision check function
local function checkCollision(player, collisionBox)
    local playerLeft = player.x - (272 * math.abs(player.xScale))/4
    local playerRight = player.x + (272 * math.abs(player.xScale))/4
    local playerTop = player.y - (256 * player.yScale)/4
    local playerBottom = player.y + (256 * player.yScale)/4

    local boxLeft = collisionBox.x - collisionBox.width/1
    local boxRight = collisionBox.x + collisionBox.width/4
    local boxTop = collisionBox.y - collisionBox.height/4
    local boxBottom = collisionBox.y + collisionBox.height/4

    return not (playerLeft > boxRight or playerRight < boxLeft or
                playerTop > boxBottom or playerBottom < boxTop)
end

-- Check vomit collision
local function checkVomitCollision(player, vomit)
    local dx = player.x - vomit.x
    local dy = player.y - vomit.y
    local distance = math.sqrt(dx*dx + dy*dy)
    return distance < 60
end

-- Update hearts display
local function updateHearts()
    for i = 1, 3 do
        if hearts[i] then
            if i <= _G.playerHealth then
                hearts[i].fill = {type="image", filename="images/muutkuvat/rakennukset/heart_full.png"}
            else
                hearts[i].fill = {type="image", filename="images/muutkuvat/rakennukset/heart_empty.png"}
            end
        end
    end
end

-- Damage player
local function damagePlayer()
    if _G.playerHealth > 0 then
        _G.playerHealth = _G.playerHealth - 0.5
        updateHearts()
        print("Health: " .. _G.playerHealth)

        if _G.playerHealth <= 0 then
            print("Game Over!")
            -- Reset health and go to menu
            _G.playerHealth = 1
            composer.gotoScene("scenes.scene_menu", {effect = "fade", time = 500})
        end
    end
end

function scene:create(event)
    local sceneGroup = self.view

    -- Start physics engine
    physics.start()
    physics.setGravity(0, 0)  -- No gravity for top-down view
    physics.setDrawMode("normal")  -- Show physics bodies (remove for final build)"hybrid" to check collisions

    -- Get screen dimensions
    local screenW = display.contentWidth
    local screenH = display.contentHeight

    -- Load background
    local backGround = display.newImageRect("images/tile_taivas.png", screenW, screenH)
    backGround.x = display.contentCenterX
    backGround.y = display.contentCenterY
    sceneGroup:insert(backGround)

    -- Load kiosk (left side, lower)
    kiosk = display.newImageRect("images/kioski.png", 200, 300)
    kiosk.x = 100
    kiosk.y = display.contentCenterY + 105
    sceneGroup:insert(kiosk)

    -- Create invisible collision box
    kioskCollisionBox = display.newRect(100, display.contentCenterY + 105, 140, 240)
    kioskCollisionBox.alpha = 0
    kioskCollisionBox.isVisible = false
    sceneGroup:insert(kioskCollisionBox)

    -- Add physics body to kiosk collision box
    physics.addBody(kioskCollisionBox, "static", { bounce=0 })
    kioskCollisionBox.collision = function(self, event)
        if event.phase == "began" then
            print("Player hit kiosk!")
        end
    end
    kioskCollisionBox:addEventListener("collision", kioskCollisionBox)

    -- UUSI: Kauppias (Monster-sprite, punainen) - VASEMMALLA
    local monsterOptions = {
        width = 120,
        height = 156,
        numFrames = 5,
        sheetContentWidth = 360,
        sheetContentHeight = 312
    }
    local monsterSheet = graphics.newImageSheet("images/muutkuvat/viholliset/bb.png", monsterOptions)
    local shopkeeper = display.newSprite(monsterSheet, {
        name = "walk",
        frames = {1, 2, 3, 4, 5},
        time = 800,
        loopCount = 0
    })
    shopkeeper.x = kiosk.x - 50
    shopkeeper.y = kiosk.y + 50
    shopkeeper.xScale = 0.8
    shopkeeper.yScale = 0.8
    shopkeeper:setFillColor(1, 0.3, 0.3)  -- Punainen sävy
    shopkeeper:setSequence("walk")
    shopkeeper:setFrame(3)  -- Pysäytä kohtaan 3/5
    sceneGroup:insert(shopkeeper)

    -- UUSI: Asiakas (NPC - käyttää samaa kuvaa kuin pelaaja, sininen) - KESKELLÄ ENSIN, SITTEN KIOSKILLE
    local npcSheet = graphics.newImageSheet("images/Sprite-0004.png", require("images.sprite-0004"))
    local customer = display.newSprite(npcSheet, {
        { name="walkRight", frames={1,2,3,4,5,6,7}, time=600, loopCount=0 },
        { name="walkLeft", frames={1,2,3,4,5,6,7}, time=600, loopCount=0 },
    })
    customer.x = display.contentCenterX  -- Aloita keskeltä
    customer.y = kiosk.y + 90
    customer:setSequence("walkRight")
    customer.xScale = 0.5
    customer.yScale = 0.5
    customer:setFillColor(0.2, 0.8, 1)  -- Sininen sävy
    customer.alpha = 0.5  -- Puoli-läpinäkyvä
    customer.hasPlayedAnimation = false  -- Seuraa animaation näyttämista
    sceneGroup:insert(customer)

    -- Add physics body to NPC
    physics.addBody(customer, "static", { bounce=0, radius=8 })
    customer.name = "npc"

    -- Keskusteluteksti bubble myyjälle (starts from kiosk position)
    local speechBubble = display.newRoundedRect(kiosk.x - 50, kiosk.y - 80, 190, 70, 8)
    speechBubble:setFillColor(0.7, 0.7, 0.7)  -- Harmaa
    speechBubble.alpha = 0.7  -- Läpinäkyvä
    speechBubble.strokeWidth = 2
    speechBubble:setStrokeColor(0, 0, 0)
    sceneGroup:insert(speechBubble)

    local speechText = display.newText({
        text = "",  -- Alkaa tyhjänä, täyttyy kirjain kerrallaan
        x = kiosk.x - 50,
        y = kiosk.y - 80,
        width = 170,
        font = native.systemFont,
        fontSize = 14,
        align = "center"
    })
    speechText:setFillColor(0, 0, 0)
    sceneGroup:insert(speechText)

    -- NPC:n keskusteluteksti bubble (starts off-screen from left)
    local npcSpeechBubble = display.newRoundedRect(-200, kiosk.y - 100, 190, 70, 8)
    npcSpeechBubble:setFillColor(0.7, 0.7, 0.7)  -- Harmaa
    npcSpeechBubble.alpha = 0.7  -- Läpinäkyvä
    npcSpeechBubble.strokeWidth = 2
    npcSpeechBubble:setStrokeColor(0, 0, 0)
    sceneGroup:insert(npcSpeechBubble)

    local npcSpeechText = display.newText({
        text = "",  -- Alkaa tyhjänä, täyttyy kirjain kerrallaan
        x = -200,
        y = kiosk.y - 100,
        width = 170,
        font = native.systemFont,
        fontSize = 14,
        align = "center"
    })
    npcSpeechText:setFillColor(0, 0, 0)
    sceneGroup:insert(npcSpeechText)

    -- Store for animation
    self.speechBubble = speechBubble
    self.speechText = speechText
    self.npcSpeechBubble = npcSpeechBubble
    self.npcSpeechText = npcSpeechText

    -- Add lamps (decorative)
    local lampPositions = {
        {x = 500, y = 460},
    }

    for i = 1, #lampPositions do
        local lamp = display.newImageRect("images/muutkuvat/objects/lamppu.png", 80, 180)
        lamp.x = lampPositions[i].x
        lamp.y = lampPositions[i].y
        sceneGroup:insert(lamp)
    end


    -- Add vomit objects (hazards)
    local vomitPositions = {
        {x = 270, y = 550},
        {x = 650, y = 570},
        {x = 450, y = 600},
        {x = 850, y = 550},
    }

    for i = 1, #vomitPositions do
        local vomit = display.newImageRect("images/muutkuvat/objects/oksennus_obj.png", 70, 30)
        vomit.x = vomitPositions[i].x
        vomit.y = vomitPositions[i].y
        sceneGroup:insert(vomit)
        vomit.hasHit = false

        -- Add physics body for vomit
        physics.addBody(vomit, "static", { bounce=0 })
        vomit.collision = function(self, event)
            if event.phase == "began" then
                print("Hit vomit at: " .. self.x .. ", " .. self.y)
            end
        end
        vomit:addEventListener("collision", vomit)

        table.insert(vomitObjects, vomit)
    end

    -- Health hearts
    for i = 1, 3 do
        local heart = display.newImageRect("images/muutkuvat/rakennukset/heart_full.png", 32, 32)
        heart.x = screenW - 40 - (i-1)*40
        heart.y = 40
        sceneGroup:insert(heart)
        hearts[i] = heart
    end

    -- Coins display
    local coinsText = display.newText({
        text = "Coins: " .. _G.playerCoins,
        x = screenW - 100,
        y = 80,
        width = 150,
        font = native.systemFont,
        fontSize = 16,
        align = "right"
    })
    coinsText:setFillColor(1, 1, 0)  -- Keltainen
    sceneGroup:insert(coinsText)
    self.coinsText = coinsText

    -- Load sprite sheet
    local walkOptions = require("images.sprite-0004")
    local walkSheet = graphics.newImageSheet("images/Sprite-0004.png", walkOptions)

    -- Create sprite
    drunkenguy = display.newSprite(walkSheet, {
        { name="walkRight", frames={1,2,3,4,5,6,7}, time=1300, loopCount=0 },
        { name="walkLeft", frames={1,2,3,4,5,6,7}, time=1300, loopCount=0 },
        { name="walkUp", frames={1,2,3,4,5,6,7}, time=1300, loopCount=0 },
        { name="walkDown", frames={1,2,3,4,5,6,7}, time=1300, loopCount=0 },
        { name="walkUpRight", frames={1,2,3,4,5,6,7}, time=1300, loopCount=0 },
        { name="walkUpLeft", frames={1,2,3,4,5,6,7}, time=1300, loopCount=0 },
        { name="walkDownRight", frames={1,2,3,4,5,6,7}, time=1300, loopCount=0 },
        { name="walkDownLeft", frames={1,2,3,4,5,6,7}, time=1300, loopCount=0 }
    })

    drunkenguy.x = display.contentCenterX
    drunkenguy.y = 490
    drunkenguy:setSequence("walkRight")
    drunkenguy.xScale = 0.5
    drunkenguy.yScale = 0.5
    sceneGroup:insert(drunkenguy)

    -- Add physics body to player (scaled to match sprite size)
    physics.addBody(drunkenguy, "dynamic", { bounce=0, radius=8 })
    drunkenguy.collision = function(self, event)
        if event.phase == "began" then
            print("Player collided with: " .. tostring(event.other.name or "unknown"))
        end
    end
    drunkenguy:addEventListener("collision", drunkenguy)

    -- Save to scene data
    self.kiosk = kiosk
    self.kioskCollisionBox = kioskCollisionBox
    self.vomitObjects = vomitObjects
    self.hearts = hearts
    self.customer = customer
    self.sceneGroup = sceneGroup
end

function scene:show(event)
    local phase = event.phase

    if phase == "will" then
        -- Update health display
        updateHearts()

        -- When coming from main scene (left), place character on right side
        if event.params and event.params.fromMain then
            drunkenguy.x = display.contentWidth - 50
            self.hasStartedDialog = false  -- Track if dialog sequence has started

            -- Set up a timer to check if player is close to NPC
            local function startDialogWhenPlayerNear()
                self.dialogCheckInterval = timer.performWithDelay(100, function()
                    -- Check if player is close to NPC (within 150 pixels)
                    local dx = drunkenguy.x - self.customer.x
                    local dy = drunkenguy.y - self.customer.y
                    local distance = math.sqrt(dx*dx + dy*dy)

                    if distance < 150 and not self.hasStartedDialog then
                        self.hasStartedDialog = true

                        -- Cancel the interval timer
                        if self.dialogCheckInterval then
                            timer.cancel(self.dialogCheckInterval)
                            self.dialogCheckInterval = nil
                        end

                        -- FIRST: NPC alkaa kävellä keskeltä kohti kioskia JA PELAA ANIMAATIOTA (vasemmalle)
                        self.customer.xScale = -0.5  -- Käännä vasemmalle
                        self.customer:play()  -- Aloita animaatio
                        transition.to(self.customer, {
                            time = 4000,
                            x = self.kiosk.x + 30,  -- Liikkuu kohti kioskia
                            onComplete = function()
                                -- Pysäytä animaatio kun saapuu kioskille
                                self.customer:pause()

                                -- TARKISTA: Onko pelaaja lähellä kioskia? Jos ei, älä aloita dialogia
                                local dxPlayer = drunkenguy.x - self.kiosk.x
                                local dyPlayer = drunkenguy.y - self.kiosk.y
                                local playerDistance = math.sqrt(dxPlayer*dxPlayer + dyPlayer*dyPlayer)

                                -- Dialogi käynnistyy vain jos pelaaja on lähellä kioskia (alle 200 pixelia)
                                if playerDistance < 200 then
                                    -- Kauppias alkaa puhua kun asiakas saapuu kioskille
                                    local fullShopkeeperText = "Last hotdog for the night,\nonly for two coins"
                                    local shopkeeperCharIndex = 1
                                    local function addShopkeeperChar()
                                        if shopkeeperCharIndex <= #fullShopkeeperText then
                                            self.speechText.text = string.sub(fullShopkeeperText, 1, shopkeeperCharIndex)
                                            shopkeeperCharIndex = shopkeeperCharIndex + 1
                                            timer.performWithDelay(80, addShopkeeperChar)
                                        end
                                    end

                                    addShopkeeperChar()

                                    -- NPC alkaa puhua kun kauppias on valmis (3 sekunttia myöhemmin)
                                    timer.performWithDelay(3000, function()
                                        self.speechText.text = ""

                                        local fullNpcText = "Yes, I feel super hungry\npass it to me.."
                                        local npcCharIndex = 1
                                        local function addNpcChar()
                                            if npcCharIndex <= #fullNpcText then
                                                self.npcSpeechText.text = string.sub(fullNpcText, 1, npcCharIndex)
                                                npcCharIndex = npcCharIndex + 1
                                                timer.performWithDelay(80, addNpcChar)
                                            end
                                        end

                                        self.npcSpeechBubble.x = self.kiosk.x + 100
                                        self.npcSpeechText.x = self.kiosk.x + 100
                                        addNpcChar()

                                        -- 4 sekuntia myöhemmin, poista NPC:n teksti ja pelaaja vastaa
                                        timer.performWithDelay(4000, function()
                                            self.npcSpeechText.text = ""
                                            self.npcSpeechBubble.x = -200
                                            self.npcSpeechText.x = -200

                                        -- Pelaaja puhuu - TARKISTA ONKO TARPEEKSI KOLIKOITA (2 kolikkoa)
                                        if _G.playerCoins >= 2 then
                                            -- Pelaaja puhuu oman puhelimen kautta
                                            local fullPlayerText = "I will buy it!\nFounr coins for the hotdog!"
                                            local playerCharIndex = 1
                                            local function addPlayerChar()
                                                if playerCharIndex <= #fullPlayerText then
                                                    self.npcSpeechText.text = string.sub(fullPlayerText, 1, playerCharIndex)
                                                    playerCharIndex = playerCharIndex + 1
                                                    timer.performWithDelay(80, addPlayerChar)
                                                end
                                            end

                                            self.npcSpeechBubble.x = drunkenguy.x
                                            self.npcSpeechText.x = drunkenguy.x
                                            addPlayerChar()

                                            -- 4 sekuntia myöhemmin, näytä hotdogi
                                            timer.performWithDelay(4000, function()
                                                    self.npcSpeechText.text = ""
                                                    self.npcSpeechBubble.x = -200
                                                    self.npcSpeechText.x = -200

                                                    -- Näytä hotdogi pelaajan vieressä
                                                    local hotdog = display.newImageRect("images/muutkuvat/objects/hodari_obj.png", 80, 50)
                                                    hotdog.x = drunkenguy.x
                                                    hotdog.y = drunkenguy.y - 80
                                                    self.sceneGroup:insert(hotdog)

                                                    -- Näytä "Press SPACE to eat" teksti
                                                    local eatPrompt = display.newText({
                                                        text = "Press SPACE to eat",
                                                        x = display.contentCenterX,
                                                        y = display.contentCenterY + 80,
                                                        width = 200,
                                                        font = native.systemFont,
                                                        fontSize = 16,
                                                        align = "center"
                                                    })
                                                    eatPrompt:setFillColor(1, 1, 1)  -- Valkoinen
                                                    self.sceneGroup:insert(eatPrompt)
                                                    self.eatPrompt = eatPrompt
                                                    self.hotdog = hotdog
                                                    self.canEatHotdog = true
                                                end)
                                            else
                                                -- Ei tarpeeksi kolikoita!
                                                local noCoinsText = "I don't have enough coins!"
                                                local noCoinsCharIndex = 1
                                                local function addNoCoinsChar()
                                                    if noCoinsCharIndex <= #noCoinsText then
                                                        self.speechText.text = string.sub(noCoinsText, 1, noCoinsCharIndex)
                                                        noCoinsCharIndex = noCoinsCharIndex + 1
                                                        timer.performWithDelay(80, addNoCoinsChar)
                                                    end
                                                end
                                                addNoCoinsChar()

                                                -- 3 sekuntia myöhemmin, poista teksti
                                                timer.performWithDelay(3000, function()
                                                    self.speechText.text = ""
                                                    self.hasStartedDialog = false  -- Salli dialog uudelleen
                                                end)
                                            end
                                        end)
                                    end)
                                else
                                    -- Pelaaja on liian kaukana, älä aloita dialogia
                                    self.hasStartedDialog = false
                                end
                            end
                        })
                    end
                end, 0)
            end

            startDialogWhenPlayerNear()
        end
        -- When coming from street scene (right), place character on left side
        if event.params and event.params.fromStreet then
            drunkenguy.x = 50
        end
    end

    if phase == "did" then
        -- Reset keys first
        for k in pairs(_G.keysPressed) do
            _G.keysPressed[k] = nil
        end

        -- Reset vomit hit status
        for i = 1, #vomitObjects do
            vomitObjects[i].hasHit = false
        end

        -- Keyboard listener
        local function onKey(event)
            if event.phase == "down" then
                keysPressed[event.keyName] = true

                -- EAT HOTDOG when pressing SPACE
                if event.keyName == "space" and self.canEatHotdog then
                    self.canEatHotdog = false

                    -- Poista hotdog ja prompti
                    display.remove(self.hotdog)
                    display.remove(self.eatPrompt)

                    -- Vähennä kolikot
                    _G.playerCoins = _G.playerCoins - 2
                    self.coinsText.text = "Coins: " .. _G.playerCoins

                    -- Näytä "PAYING 2 COINS" teksti
                    local payingText = display.newText({
                        text = "PAYING 2 COINS",
                        x = drunkenguy.x,
                        y = drunkenguy.y - 150,
                        width = 200,
                        font = native.systemFont,
                        fontSize = 20,
                        align = "center"
                    })
                    payingText:setFillColor(1, 0, 0)  -- Punainen
                    self.sceneGroup:insert(payingText)

                    -- 1 sekunti myöhemmin, näytä "EATING.." teksti
                    timer.performWithDelay(1000, function()
                        display.remove(payingText)

                        local eatingText = display.newText({
                            text = "EATING..",
                            x = drunkenguy.x,
                            y = drunkenguy.y - 80,
                            width = 200,
                            font = native.systemFont,
                            fontSize = 20,
                            align = "center"
                        })
                        eatingText:setFillColor(1, 1, 0)  -- Keltainen
                        self.sceneGroup:insert(eatingText)

                        -- 1 sekunti myöhemmin, täytä terveysarvot
                        timer.performWithDelay(1000, function()
                            display.remove(eatingText)

                            -- Täytä terveysarvot
                            _G.playerHealth = 3
                            updateHearts()

                            -- Näytä "+FULL HEALTH" teksti vihreällä
                            local healthText = display.newText({
                                text = "+FULL HEALTH",
                                x = drunkenguy.x,
                                y = drunkenguy.y - 120,
                                width = 200,
                                font = native.systemFont,
                                fontSize = 24,
                                align = "center"
                            })
                            healthText:setFillColor(0, 1, 0)  -- Vihreä
                            self.sceneGroup:insert(healthText)

                            -- 2 sekuntia myöhemmin, poista teksti ja ota syöty-flagi käyttöön
                            timer.performWithDelay(2000, function()
                                display.remove(healthText)
                                self.hasEatenHotdog = true
                            end)
                        end)
                    end)
                    return true
                end
            elseif event.phase == "up" then
                keysPressed[event.keyName] = false
            end
            return false
        end

        -- Continuous update
        local sceneActive = true
        local function gameLoop()
            if not sceneActive then return end

            -- Save old position
            local oldX = drunkenguy.x
            local oldY = drunkenguy.y

            currentFrequence = playerMovement.update(drunkenguy, keysPressed, currentFrequence, speed)

            -- Check collision with kiosk (use collision box)
            if checkCollision(drunkenguy, kioskCollisionBox) then
                -- Restore old position if collision
                drunkenguy.x = oldX
                drunkenguy.y = oldY
            end

            -- Check vomit collision
            for i = 1, #vomitObjects do
                local vomit = vomitObjects[i]
                if not vomit.hasHit and checkVomitCollision(drunkenguy, vomit) then
                    vomit.hasHit = true
                    damagePlayer()
                end
            end

            -- Check scene transition: right -> main
            if drunkenguy.x > display.contentWidth then
                sceneActive = false
                Runtime:removeEventListener("key", self.onKey)
                Runtime:removeEventListener("enterFrame", self.gameLoop)
                composer.gotoScene("scenes.scene_main", {
                    effect = "slideLeft",
                    time = 300,
                    params = { fromKiosk = true }
                })
            end

            -- Check scene transition: left -> street (jos hotdog on syöty)
            if self.hasEatenHotdog and drunkenguy.x < 0 then
                sceneActive = false
                Runtime:removeEventListener("key", self.onKey)
                Runtime:removeEventListener("enterFrame", self.gameLoop)
                composer.gotoScene("scenes.scene_street", {
                    effect = "slideLeft",
                    time = 300,
                    params = { fromKiosk = true }
                })
            end
        end

        Runtime:addEventListener("key", onKey)
        Runtime:addEventListener("enterFrame", gameLoop)

        -- Save listeners for cleanup
        self.onKey = onKey
        self.gameLoop = gameLoop
    end
end

function scene:hide(event)
    local phase = event.phase

    if phase == "will" then
        -- Remove listeners
        if self.onKey then
            Runtime:removeEventListener("key", self.onKey)
        end
        if self.gameLoop then
            Runtime:removeEventListener("enterFrame", self.gameLoop)
        end
        if self.dialogCheckInterval then
            timer.cancel(self.dialogCheckInterval)
            self.dialogCheckInterval = nil
        end

        -- Reset all key presses
        for k in pairs(_G.keysPressed) do
            _G.keysPressed[k] = nil
        end

        -- Pause physics
        physics.pause()
    end
end

function scene:destroy(event)
    -- Cleanup if needed
end

scene:addEventListener("create", scene)
scene:addEventListener("show", scene)
scene:addEventListener("hide", scene)
scene:addEventListener("destroy", scene)

return scene